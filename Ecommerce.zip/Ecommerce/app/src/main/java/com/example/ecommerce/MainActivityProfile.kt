package com.example.ecommerce

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import com.example.ecommerce.databinding.ActivityMainProfileBinding
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase

class MainActivityProfile : AppCompatActivity() {
    private lateinit var auth: FirebaseAuth
    private lateinit var db : FirebaseFirestore
    private lateinit var fullName : TextView
    private lateinit var email : TextView
    private lateinit var photoProfile : ImageView
    private lateinit var loading: ProgressBar
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        this.setTitle(R.string.profile)

        val binding = ActivityMainProfileBinding.inflate(layoutInflater)

        setContentView(binding.root)
        auth = Firebase.auth
        db = Firebase.firestore
        val btnSignOut = binding.btnSignOut
        photoProfile = binding.profilePhotoProfile
        email = binding.profileEmail
        fullName = binding.profilaFullname
        loading = binding.profileLoading
        loading.visibility = View.GONE

        btnSignOut.setOnClickListener {
            loading.visibility = View.VISIBLE
            auth.signOut()
            reload()
        }
    }

    override fun onStart() {
        super.onStart()
        val currentUser = auth.currentUser
        if(currentUser != null){
            email.text = currentUser.email
            getPersonalInfo(currentUser.uid)
        }else{
            reload()
        }
    }

    private fun reload() {
        val intent = Intent(this@MainActivityProfile,MainActivity::class.java)
        startActivity(intent)
    }

    private fun getPersonalInfo(uid: String){
        loading.visibility = View.VISIBLE
        db.collection("user")
            .whereEqualTo("id", uid)
            .get()
            .addOnSuccessListener { documents ->
                loading.visibility = View.GONE
                for (document in documents) {
                    Log.d(MainActivity.TAG, "${document.id} => ${document.data["fullName"]}")
                    fullName.text = "${document.data["fullName"]}"
                }
            }
            .addOnFailureListener { exception ->
                loading.visibility = View.GONE
                Log.w(MainActivity.TAG, "Error getting documents: ", exception)
            }
    }


}