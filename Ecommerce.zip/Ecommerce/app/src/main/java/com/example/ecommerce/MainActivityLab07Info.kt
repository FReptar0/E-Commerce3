package com.example.ecommerce

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.ecommerce.databinding.ActivityPrintBinding

class MainActivityLab07Info : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main_lab07_info)
        this.title = "Lab 07 Info"
        val binding = ActivityPrintBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val bundle = intent.extras

        val name = bundle?.get("name").toString()
        val address = bundle?.get("address").toString()
        val city = bundle?.get("city").toString()
        val state = bundle?.get("state").toString()
        val postal = bundle?.get("zip").toString()
        val country = bundle?.get("country").toString()

        val txtName = binding.txtName
        val txtAddress = binding.txtAddress
        val txtCity = binding.txtCity
        val txtState = binding.txtState
        val txtPostal = binding.txtZip
        val txtCountry = binding.txtCountry

        txtName.text = name
        txtAddress.text = address
        txtCity.text = city
        txtState.text = state
        txtPostal.text = postal
        txtCountry.text = country
    }
    }