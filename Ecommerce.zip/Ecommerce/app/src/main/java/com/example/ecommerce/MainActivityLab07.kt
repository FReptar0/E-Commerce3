package com.example.ecommerce

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import com.example.ecommerce.databinding.ActivityFormBinding
import com.example.ecommerce.databinding.ActivityMainLab07InfoBinding

class MainActivityLab07 : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)


        this.title = "Lab 07"


        val binding = ActivityFormBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val btnNext = binding.btnSchedule

        btnNext.setOnClickListener {
            val name = binding.lab07Name.text.toString()
            val address = binding.lab07Address.text.toString()
            val city = binding.lab07City.text.toString()
            val state = binding.lab07State.text.toString()
            val zip = binding.lab07Cp.text.toString()
            val country = binding.lab07Country.text.toString()

            if (name.isNotEmpty() && address.isNotEmpty() && city.isNotEmpty() && state.isNotEmpty() && zip.isNotEmpty() && country.isNotEmpty()){
                sendData(name, address, city,state,zip,country)
            }else{
                Toast.makeText(this@MainActivityLab07,R.string.validation_required_fields,
                    Toast.LENGTH_SHORT).show()
            }
        }

    }

    private fun sendData(name: String, address: String, city: String, state: String, zip: String,country: String){
        intent = Intent(this@MainActivityLab07, MainActivityLab07Info::class.java)
        intent.putExtra("name",name)
        intent.putExtra("address", address)
        intent.putExtra("city", city)
        intent.putExtra("state", state)
        intent.putExtra("zip",zip)
        intent.putExtra("country", country)

        startActivity(intent)
    }

}