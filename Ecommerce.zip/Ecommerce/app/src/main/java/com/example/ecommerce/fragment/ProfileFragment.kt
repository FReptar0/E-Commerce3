package com.example.ecommerce.fragment

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import androidx.fragment.app.Fragment
import com.example.ecommerce.MainActivity
import com.example.ecommerce.R
import com.example.ecommerce.databinding.FragmentProfileBinding
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import com.squareup.picasso.Picasso

class ProfileFragment : Fragment() {
    private var _binding: FragmentProfileBinding? = null
    private val binding get() = _binding!!

    private lateinit var auth: FirebaseAuth
    private lateinit var db : FirebaseFirestore
    private lateinit var fullName : TextView
    private lateinit var photoProfile : ImageView
    private lateinit var email : TextView
    private lateinit var loading: ProgressBar


    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentProfileBinding.inflate(inflater,container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        activity?.setTitle(R.string.profile)

        auth = Firebase.auth
        db = Firebase.firestore
        val btnSignOut = binding.btnSignOut
        val btnEditProfile = binding.btnEditProfile
        val btnEditPass = binding.btnEditPass
        photoProfile = binding.profilePhotoProfile

        email = binding.profileEmail
        fullName = binding.profilaFullname
        loading = binding.profileLoading
        loading.visibility = View.GONE

        val modalDialog = EditProfileFragment()


        btnSignOut.setOnClickListener {
            loading.visibility = View.VISIBLE
            auth.signOut()
            reload()
        }

        btnEditProfile.setOnClickListener {
            modalDialog.show(requireActivity().supportFragmentManager, "confirmDialog")
        }

        btnEditPass.setOnClickListener {


        }

        

    }

    override fun onStart() {
        super.onStart()
        val currentUser = auth.currentUser
        if(currentUser != null){
            email.text = currentUser.email
            getPersonalInfo(currentUser.uid)
        }else{
            reload()
        }
    }

    private fun reload() {
        loading.visibility = View.GONE
        val intent = Intent(activity, MainActivity::class.java)
        startActivity(intent)
    }

    private fun getPersonalInfo(uid: String){
        loading.visibility = View.VISIBLE
        db.collection("user")
            .whereEqualTo("id", uid)
            .get()
            .addOnSuccessListener { documents ->
                loading.visibility = View.GONE
                for (document in documents) {
                    Log.d(MainActivity.TAG, "${document.id} => ${document.data["fullName"]}")
                    fullName.text = "${document.data["fullName"]}"
                    Picasso.get().load(document.data["photo_profile"].toString()).into(binding.profilePhotoProfile)
                }
            }
            .addOnFailureListener { exception ->
                loading.visibility = View.GONE
                Log.w(MainActivity.TAG, "Error getting documents: ", exception)
            }
    }

}