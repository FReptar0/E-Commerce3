package com.example.ecommerce

import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.annotation.RequiresApi
import androidx.fragment.app.Fragment
import com.example.ecommerce.databinding.FragmentProfileBinding
import com.example.ecommerce.fragment.ProfileFragment
import com.example.ecommerce.fragment.ShopFragment
import com.example.ecommerce.fragment.WebServiceFragment
import com.google.android.material.bottomnavigation.BottomNavigationView

class MainActivityMenu : AppCompatActivity() {

    private val profileFragment = ProfileFragment()
    private val shopFragment = ShopFragment()
    private val webServiceFragment = WebServiceFragment()

    @RequiresApi(Build.VERSION_CODES.O)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main_menu)
        replaceFragment(profileFragment)
        val bottomNavigation: BottomNavigationView = findViewById(R.id.menu_bottom_navigation)
        bottomNavigation.setOnNavigationItemReselectedListener{
            when(it.itemId){
                R.id.item_webService -> replaceFragment(webServiceFragment)
                R.id.item_shop -> replaceFragment(shopFragment)
                R.id.item_profile -> replaceFragment(profileFragment)
            }
            true
        }

    }

    private fun replaceFragment(fragment: Fragment){
        if (fragment != null){
            val transaction = supportFragmentManager.beginTransaction()
            transaction.replace(R.id.menu_fragment_conainer, fragment)
            transaction.commit()
        }
    }
}